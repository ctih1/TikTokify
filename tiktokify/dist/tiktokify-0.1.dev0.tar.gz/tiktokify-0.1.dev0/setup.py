from setuptools import setup, find_packages
import sys, os

version = '0.1'

setup(name='tiktokify',
      version=version,
      description="Make those Family Guy clip pages on TikTok",
      long_description="""\
A program that gets 2 videos (top and bottom), stacks them on eachother, and exports the combined video.""",
      classifiers=[], # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
      keywords='tiktok python moviepy automation familyguy',
      author='Onni Nevala',
      author_email='onni09nevala@gmail.com',
      url='https://github.com/ctih1',
      license='MIT',
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      include_package_data=True,
      zip_safe=True,
      install_requires=[
          # -*- Extra requirements: -*-
      ],
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
